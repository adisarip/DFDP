
#include <iostream>

#include <deque>
#include <list>

#include <string>
#include <algorithm>
#include <exception>

using namespace std;

#include "operation.h"
#include "job.h"
#include "task.h"

#include "compare.h"
#include "slack_compare.h"

#include "job_deque.h"
#include "slack_deque.h"


// LST non strict 


void slack_deque::insert (job* job_ptr) {
	_deque.push_back(job_ptr);	
}

job* slack_deque::extract (void* user) {
	stable_sort(_deque.begin(), _deque.end(), _compare);
	job* extracted = _deque.front();
	return extracted;
}

slack_deque::slack_deque()
{
}

slack_deque::~slack_deque()
{
}
