#ifndef LIFO_DEQUE_H_
#define LIFO_DEQUE_H_

class lifo_deque : public job_deque
{
	stack_compare _compare;
	
public:
	void insert (job* job_ptr);
	job* extract (void* user);
	
	lifo_deque();
	~lifo_deque();
};

#endif /*LIFO_DEQUE_H_*/
