
#include <iostream>

#include <deque>
#include <list>

#include <string>
#include <algorithm>
#include <exception>

using namespace std;

#include "operation.h"
#include "job.h"
#include "task.h"

#include "compare.h"
#include "stack_compare.h"

#include "job_deque.h"
#include "lifo_deque.h"


// LIFO (usa stack_compare.h) 


void lifo_deque::insert (job* job_ptr) {
	_deque.push_back(job_ptr);	
}

job* lifo_deque::extract (void* user) {
	stable_sort(_deque.begin(), _deque.end(), _compare);
	job* extracted = _deque.front();
	return extracted;
}

lifo_deque::lifo_deque()
{
}

lifo_deque::~lifo_deque()
{
}
