#ifndef FIFO_DEQUE_H_
#define FIFO_DEQUE_H_

class fifo_deque : public job_deque
{
	release_compare _compare;
	
public:
	void insert (job* job_ptr);
	job* extract (void* user);
	
	fifo_deque();
	~fifo_deque();
};

#endif /*FIFO_DEQUE_H_*/
