#ifndef SCHEDULER_H_
#define SCHEDULER_H_

class scheduler
{
public:
	float current_time; // current time
	
	job* running; // current running job
	
	//deque<job*> event_queue;
	job_deque& event_queue; //sar� del tipo release_queue
	//deque<job*> ready_queue;
	job_deque& ready_queue; //sar� del tipo deadline_queue
	
	deque<job*> term_queue;
	
//	compare& event_cmp; // or event_queue sorter
//	compare& ready_cmp; // or scheduling policy
	
public:
	//scheduler(compare& , compare& );
	scheduler(job_deque& , job_deque& );
	virtual ~scheduler();

	void run( list<task>& task_list, list<job>& job_list, float runlength );
	
	//inline deque<job*>& getEventQueue()
	inline job_deque& getEventQueue()
	{ return event_queue; };
	inline job_deque& getReadyQueue() 
	{ return ready_queue; };
	
	inline deque<job*>& getTerminatedQueue() 
	{ return term_queue; };
	
private:
	int init_event( list<task>& task_list, list<job>& job_list, float runlength );
	int init_ready(); 
	int step_event(); // return -1 when no more jobs on the event queue
	int step_ready(); // return -1 when no moe jobs on the ready queue	
};

#endif /*SCHEDULER_H_*/
