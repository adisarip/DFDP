#ifndef DEADLINE_DEQUE_H_
#define DEADLINE_DEQUE_H_

class deadline_deque : public job_deque
{
	deadline_compare _compare;
	
public:
	void insert (job* job_ptr);
	job* extract (void* user);
	
	deadline_deque();
	~deadline_deque();
};

#endif /*DEADLINE_DEQUE_H_*/
