#ifndef TASK_H_
#define TASK_H_


class task
{
protected:
	string name;
	
	float phase;
	float period;
	float exec;
	float deadline;
	
	float util;
	int decimals;
		
	int id;
	static int count;

	list<job> jobs;
	
public:
	task()
	: name("?"), phase(0.0), period(0.0), exec(0.0), deadline(0.0), util(0.0), decimals(0) 
	{ id = count++; };
	
	task(float phi, float p, float d, float e) 
	: name("?"), phase(phi), period(p), exec(e), deadline(d)
	{ if ( p ) util = (float)(e) / (float)(p); else util = 0.0;
	  decimals = 0;
	  id = count++;
	};
	
	task(string n, float phi, float p, float d, float e) 
	: name(n), phase(phi), period(p), exec(e), deadline(d)
	{ if ( p ) util = (float)(e) / (float)(p); else util = 0.0;
	  decimals = 0;
	  id = count++;
	};
	
	virtual ~task()
	{};

	bool operator< (const task& rhs) const;
	
	// standard get methods
	inline string getName() const
	{ return name; };
	inline float getPhase() const
	{ return phase; };
	inline float getPeriod() const
	{ return period; };	
	inline float getExec() const
	{ return exec; };
	inline float getDeadline() const
	{ return deadline; };
	inline int getDecimals() const
	{ return decimals; };
	
	inline int getId() const
	{ return id; };
	
	// return the list of jobs
	inline list<job>& getList()
	{ return jobs; }; 
	
	void toStream(ostream& output) const;
	int fromStream(istream& input);
	
	job& addJob (float r, float d, float e);
	
};

#endif /*TASK_H_*/
