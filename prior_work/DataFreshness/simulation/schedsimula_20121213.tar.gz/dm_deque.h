#ifndef DM_DEQUE_H_
#define DM_DEQUE_H_

class dm_deque : public job_deque
{
	dm_compare _compare;
	
public:
	void insert (job* job_ptr);
	job* extract (void* user);

	dm_deque();
	~dm_deque();
};

#endif /*DM_DEQUE_H_*/
