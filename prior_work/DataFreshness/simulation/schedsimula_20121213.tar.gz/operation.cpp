#include <iostream>
#include <string>
#include <list>

using namespace std;

#include "operation.h"
#include "job.h"
#include "task.h"

/*
operation::operation()
{
}
*/

operation::~operation()
{
}

operation& operation::operator= (const operation& rhs) {
	if ( this == &rhs )
		return (*this);
	
	this->begin = rhs.begin;
	this->end = rhs.end;
	this->parent_job = rhs.parent_job;
	
	return (*this);
}
