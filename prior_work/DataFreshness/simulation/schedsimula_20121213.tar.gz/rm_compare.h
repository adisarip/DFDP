#ifndef RM_COMPARE_H_
#define RM_COMPARE_H_

struct rm_compare : public compare
{
	bool operator() (const job& a,const job& b)
	{ //cout << "rm_comp job& job&" << endl;
		return ( (a.getParent()).getPeriod() < (b.getParent()).getPeriod() );
	}
	
	bool operator() (job*& a,job*& b)
	{ //cout << "rm_comp job*& job*&" << endl;
		return ( (a->getParent()).getPeriod() < (b->getParent()).getPeriod() );
	}

	bool operator() (job* const& a,job*& b)
	{ //cout << "rm_comp job* const& job*&" << endl;
		return ( (a->getParent()).getPeriod() < (b->getParent()).getPeriod() );
	}

	bool operator() (job*& a,job* const& b)
	{ //cout << "rm_comp job*& job* const&" << endl;
		return ( (a->getParent()).getPeriod() < (b->getParent()).getPeriod() );
	}
	
	~rm_compare() { }
};

#endif /*RM_COMPARE_H_*/
