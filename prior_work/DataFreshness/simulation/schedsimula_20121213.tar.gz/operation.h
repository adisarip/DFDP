#ifndef OPERATION_H_
#define OPERATION_H_

//forward declaration
class job;

class operation
{
protected:
	job * parent_job; // must be a reference TODO
	
	float begin;
	float end;
		
public:
	operation(const operation& op) // copy constructor
	:parent_job(op.parent_job), begin(op.begin), end(op.end)
	{};
	operation(job& parent, float b, float e)
	:parent_job(&parent), begin(b), end(e)
	{};
	operation(job& parent)
	:parent_job(&parent), begin(0), end(0)
	{};
	virtual ~operation();
	
	operation& operator= (const operation& rhs); // assignment operator
	
	inline job& getParent() const
	{ return * parent_job; };
	inline float getBegin() const
	{ return begin; };
	inline float getEnd() const
	{ return end; };
};

#endif /*OPERATION_H_*/
