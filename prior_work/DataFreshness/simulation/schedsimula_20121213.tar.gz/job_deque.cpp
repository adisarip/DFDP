#include <iostream>

#include <deque>
#include <list>

#include <string>
#include <algorithm>
#include <exception>
#include <iterator>

using namespace std;

#include "operation.h"
#include "job.h"
#include "task.h"

#include "job_deque.h"

job* job_deque::remove (void* user)
{
		job* extracted = extract(user);
		_deque.pop_front();
		return extracted;
}
	
void job_deque::toStream(ostream& output) 
{
		std::deque<job*>::iterator ijob;
		for (ijob = _deque.begin(); ijob < _deque.end(); ijob++ )
			output << "job"<< (*ijob)->getRelease() << ',' 
				<< (*ijob)->getDeadline() << ","
				<< (*ijob)->getExec() << 't'
				<< ((*ijob)->getParent()).getId() << ' ';
		output << endl;
}
