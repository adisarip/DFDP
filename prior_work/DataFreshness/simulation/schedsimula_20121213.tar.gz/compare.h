#ifndef COMPARE_H_
#define COMPARE_H_

/*
 * non possiamo usarla perche i template non supportano le classe
 * astratte/interfaccie
 * infatti le virtual table vengono costruite a tempo di linking 
 * non a tempo di compilazione mentre i template vengono
 * costruiti a tempo di compilazione per questo motivo ignorano
 * le tabelle virtuali.
 * http://groups.google.com/group/comp.lang.c++.moderated/browse_thread/thread/9bdd731eea5d1455
 * Per questo motivo non possiamo usare l'hineritance con i template
 */

#include <iostream>
#include <functional>
using namespace std;

struct compare : public binary_function<job, job, bool> {
	virtual bool operator() (const job& a, const job& b) = 0;
	virtual bool operator() (job*& a, job*& b) = 0;
	virtual bool operator() (job* const& a, job*& b) = 0;
	virtual bool operator() (job*& a, job* const& b) = 0;
	//virtual ~compare() = 0; //destructor must be implemented, so it is better to be commented
};

#endif /*COMPARE_H_*/
