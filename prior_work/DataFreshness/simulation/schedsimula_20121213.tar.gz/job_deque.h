#ifndef JOB_DEQUE_H_
#define JOB_DEQUE_H_

/*
interfaccia da implementare per incodare jobs che possiamo usare in event e in ready
facciamo la prima prova con ready 
Questa e un INTERRFACCIa e serve per poi poter passare diverse politiche di scheduling allo scheduler
*/ 

/* protected in modo tale che chi usa la job queue non puo
 * accedere ai metodi della deque 
 */
// class job_queue : protected deque<job*> {

/* in STL stack non viene usata l'inheritance bens� 
 * un vector/deque/queue etc vengono utilizzati come parametri per la
 * templetizzazione e sono un field della classe stack
 * possiamo o fare allo stesso modo..
 */

// in ready queue mi servono solo insert e extract
// in event queue invece mi servono non solo insert e extract ma anche get )del
// piu prioritario [altrimenti dobbiamo fare extract e insert (sostituiscono la 
// necessita di farsi tornare il piu prioritario..]

// extract ti permette di passare un parametro utente come il tempo
// metti caso che vuoi crearti una politica di scheduling strana che ha bisogno di parametri..

/*NOTA questa classe deve esser un interfaccia perch�
 * nel caso fosse una classe astratta si metterebbe il campo
 * _deque in job_deque ma questo andrebbe di nuovo a fregarci con il template
 * anche se sarebbe da verificare che tutto abbia senso facendo un casting prima del template 
*/

// abstract class (last mod)

class job_deque
{
	
protected:
	deque<job*> _deque;
	
public:
	// NOTA in stl il metodo ::insert permette di inserire piu elementi dentro una sequenza
	virtual void insert (job* job_ptr) = 0;
	// sort the deque and return the most prioritary (following the sorting policy)
	virtual job* extract (void* user) = 0;
	// come extract ma anche rimuove il job
	virtual job* remove (void* user);
	
	virtual void toStream(ostream& output);
		
	virtual inline size_t size() const 
	{ return _deque.size(); }
	virtual inline bool empty () const
	{ return _deque.empty(); }
	
	virtual ~job_deque()
	{ } ;
};


#endif /*JOB_DEQUE_H_*/
