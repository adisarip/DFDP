#ifndef RM_DEQUE_H_
#define RM_DEQUE_H_

class rm_deque : public job_deque
{
	rm_compare _compare;
	
public:
	void insert (job* job_ptr);
	job* extract (void* user);

	rm_deque();
	~rm_deque();
};

#endif /*RM_DEQUE_H_*/
