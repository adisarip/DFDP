#include <iostream>
#include <string>
using namespace std;

#include "event.h"

const char* event::event_names[] = {"START", "STOP", "DEADLINE", "EXEC-B",
	"EXEC-E", "READY-B", "READY-E", "LOCK", "UNLOCK", "ARROWDOWN",
	"ARROWUP", "BLOCK", "VLINE", "TEXTOVER", "TEXTUNDER"};

void event::toStream(ostream& output) const
{
	output << time << ' ';
	output << event_names[type] << ' ';
	output << task_id <<  ' ';
	output << endl; // optionally the color
}

event::~event()
{
}


bool event::operator< (const event& rhs) const
{
	return (time >= rhs.time);
}

/*
class EVENTCompare {
public:
	bool operator() (const event& a,const event& b)
	{ 	 
		  return ( a < b );
	}
} event_compare;
*/
