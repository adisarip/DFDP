
#include <iostream>

#include <deque>
#include <list>

#include <string>
#include <algorithm>
#include <exception>

using namespace std;

#include "operation.h"
#include "job.h"
#include "task.h"

#include "compare.h"
#include "release_compare.h"

#include "job_deque.h"
#include "fifo_deque.h"


// FIFO (usa release_compare.h) 


void fifo_deque::insert (job* job_ptr) {
	_deque.push_back(job_ptr);	
}

job* fifo_deque::extract (void* user) {
	stable_sort(_deque.begin(), _deque.end(), _compare);
	job* extracted = _deque.front();
	return extracted;
}

fifo_deque::fifo_deque()
{
}

fifo_deque::~fifo_deque()
{
}
