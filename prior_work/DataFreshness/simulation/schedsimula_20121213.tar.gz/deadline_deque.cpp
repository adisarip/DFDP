
#include <iostream>

#include <deque>
#include <list>

#include <string>
#include <algorithm>
#include <exception>

using namespace std;

#include "operation.h"
#include "job.h"
#include "task.h"

#include "compare.h"
#include "deadline_compare.h"

#include "job_deque.h"
#include "deadline_deque.h"


// nel caso della coda EDF scegliamo di fare il sort prima di estrarre 


void deadline_deque::insert (job* job_ptr) {
	_deque.push_back(job_ptr);	
}

job* deadline_deque::extract (void* user) {
	stable_sort(_deque.begin(), _deque.end(), _compare);
	job* extracted = _deque.front();
	return extracted;
}

deadline_deque::deadline_deque()
{
}

deadline_deque::~deadline_deque()
{
}
