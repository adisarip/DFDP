
#ifndef STACK_COMPARE_H_
#define STACK_COMPARE_H_

struct stack_compare : public compare
{
	bool operator() (const job& a,const job& b)
	{ //cout << "stack_comp job& job&" << endl;
		return (a.getRelease() > b.getRelease());
	}
	
	bool operator() (job*& a,job*& b)
	{ //cout << "stack_comp job*& job*&" << endl;
		return (a->getRelease() > b->getRelease());
	}

	bool operator() (job* const& a,job*& b)
	{ //cout << "stack_comp job* const& job*&" << endl;
		return (a->getRelease() > b->getRelease());
	}

	bool operator() (job*& a,job* const& b)
	{ //cout << "stack_comp job*& job* const&" << endl;
		return (a->getRelease() > b->getRelease());
	}
	
	~stack_compare() { }
};

#endif /*STACK_COMPARE_H_*/
