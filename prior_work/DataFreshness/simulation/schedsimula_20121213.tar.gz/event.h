#ifndef EVENT_H_
#define EVENT_H_

/* devo fare attenzione a che eventi ho come algoritmo
 * e che eventi ho come Kiwi : possono essere diversi!
 */

class event
{
protected:
	static const char* event_names[];
	
public:	
	typedef enum event_types {
		START = 0,
		STOP,
		DEADLINE,
		EXEC_B, 	  	 
		EXEC_E, 	 
		READY_B, 	  	 
		READY_E, 	 
		LOCK,
		UNLOCK,
		ARROWDOWN,
		ARROWUP,
		BLOCK,
		VLINE,
		TEXTOVER,
		TEXTUNDER,
	} types;
	
protected:
	types type;
	float time;
	int task_id;
	//int color; //optionally we can also hanlde colors (actually we do not handle colors)
	
public:
	event()
	: type(START), time(0.0), task_id(0)
	{ };
	event(types t, float time, int task)
	: type(t), time(time), task_id(task)
	{ };
	
	void toStream(ostream& output) const;	
	virtual ~event();
	bool operator< (const event& rhs) const;
};

#endif /*EVENT_H_*/
