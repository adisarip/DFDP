//============================================================================
// Name        : sched_sim.cpp
// Author      : Antonio Barbalace
// Version     : 2.0
// Copyright   : Copyright (C) 2011 Antonio Barbalace
// Description : SCHEDuler SIMulator
//============================================================================

#include <iostream>
#include <fstream>
#include <list>
#include <deque>
#include <algorithm>
#include <iterator>

#include <cmath>
#include <cctype>
#include <cstdio>

using namespace std;

extern "C" {
 #include <unistd.h>
 #include <string.h>
}

#include "operation.h"
#include "job.h"
#include "task.h"

#include "compare.h"
#include "release_compare.h"
#include "deadline_compare.h"
#include "slack_compare.h"
#include "rm_compare.h"
#include "dm_compare.h"
#include "stack_compare.h"

#include "job_deque.h"
#include "release_deque.h"
#include "deadline_deque.h"
#include "slack_deque.h"
#include "rm_deque.h"
#include "dm_deque.h"
#include "fifo_deque.h"
#include "lifo_deque.h"

#include "scheduler.h"
#include "event.h"


#define DEFAULT_INPUT "task.list"
#define DEFAULT_OUTPUT "sched.ktr"
#define DEFAULT_POLICY "edf"
#define DEFAULT_RUNLENGTH 0.0

// event queue sorting policies
release_deque releaseDeq;

// ready queue sorting policies
deadline_deque deadlineDeq;
slack_deque slackDeq;
rm_deque rmDeq;
dm_deque dmDeq;
fifo_deque fifoDeq;
lifo_deque lifoDeq;

job_deque* policy_deque[] = {&deadlineDeq, &slackDeq, &rmDeq, &dmDeq, &fifoDeq, &lifoDeq};
char* policy_name[] = {"edf", "lst", "rm", "dm", "fifo", "lifo"};


/*
 * Great Common Divisor
 */
int GCD(int a, int b) {
	int c;
	if ( a<b ) {
	    c = a;
	    a = b;
	    b = c;
	}
	while (1) {
		c = a%b;
		if(c==0)
		  return b;
		a = b;
		b = c;
	}
}

/*
 * least common multiple
 */
int lcm (int a, int b) {
	//cout <<  a << " " << b << " " << GCD(a,b) << endl;
	return (a*b) / GCD(a, b);
}

/*
 * print the usage page
 */
void print_usage () {
	printf("Usage: sched_sim [-o outputfile] [-p schedpolicy] [-r runlength] [FILE]\n\n");
	printf("Run the selected scheduling algorithm on the tasks listed in the FILE.\n");
	printf("Supported algorithms:");
	for (unsigned int i=0; i<(sizeof(policy_deque)/sizeof(job_deque*)); i++)
		printf(" %s", policy_name[i]);
	
	printf("\n");
	printf("The tasks list must follow this format: %%s %%f %%f %%f %%f\\n\n");
	printf("The string is the name of the task then the phase, period, execution\n"
			"time and relative deadline.\n\n");
	printf("Report bugs to <antonio.barbalace@gmail.com>\n");
	return;
}

/*
 * job list to event list
 * events are in "Kiwi format"
 */
deque<event> jobToEventsList( deque<job*>& job_list) {
	std::deque<event> pqevent;
	job * tmp_job = 0;
	
	while (!job_list.empty()) {
//		if (tmp_job) delete tmp_job;
		tmp_job = job_list.front(); job_list.pop_front();
		int par = (tmp_job->getParent()).getId();
		
		//generate events
		event ev_ready_b(event::READY_B, (float)tmp_job->getRelease(), par); pqevent.push_back(ev_ready_b);
		event ev_start(event::START, (float)tmp_job->getRelease(), par); pqevent.push_back(ev_start);
		event ev_dead(event::DEADLINE, (float)tmp_job->getDeadline(), par); pqevent.push_back(ev_dead);
		
		// DEBUG
		//cout << "job" << tmp_job->getRelease() << ',' << tmp_job->getDeadline() << 't' << par << ':'; 
		
		list<operation> lista = tmp_job->getList();
//		operation * tmp_operation = 0;
		float last = 0.0;
		while ( !(lista.empty()) ) {
			operation tmp_operation = lista.front(); lista.pop_front();
//			if (tmp_operation) delete tmp_operation;
//			tmp_operation = &lista.front(); lista.pop_front();
		
			event ev_exec_b(event::EXEC_B, (float)tmp_operation.getBegin(), par); pqevent.push_back(ev_exec_b);
			event ev_exec_e(event::EXEC_E, last = (float)tmp_operation.getEnd(), par); pqevent.push_back(ev_exec_e);
			// DEBUG
			//cout << tmp_operation.getBegin() << ',' << tmp_operation.getEnd() << ':';
		}
		
		// check for deadline miss
//		if ( (float)tmp_operation->getEnd() > tmp_job->getDeadline()) {
		if ( last > tmp_job->getDeadline() ) {
			event ev_deadmiss(event::ARROWDOWN, tmp_job->getDeadline(), par); pqevent.push_back(ev_deadmiss);
			cout << "Task " << tmp_job->getParent().getName() << " job released at " << tmp_job->getRelease() << " misses deadline at " <<  tmp_job->getDeadline() << endl;
		}
//		if (tmp_operation) delete tmp_operation;
			
		event ev_stop(event::STOP, last, par); pqevent.push_back(ev_stop);
		event ev_ready_e(event::READY_E, last, par); pqevent.push_back(ev_ready_e);
		// DEBUG
		//cout << endl;
	}

	// Kiwi requires events sorted on when they take place
	stable_sort(pqevent.begin(), pqevent.end());
	
	return pqevent;
}



/*
 * SCHEDuler SIMulator main
 */
int main(int argc, char** argv) {
	cout << "SCHEDuler SIMulator" << endl;
	
////////////////////////////////////////////////////////////////////////////////
// command line argument parsing
////////////////////////////////////////////////////////////////////////////////	

//http://www.gnu.org/s/libc/manual/html_node/Getopt.html
	char* input_file = DEFAULT_INPUT;
	char* output_file = DEFAULT_OUTPUT;
	char* sched_policy = DEFAULT_POLICY;
	float runlength = 0.0;

    opterr = 0; // external
    char c;
    while ((c = getopt (argc, argv, "o:p:r:h")) != -1)
    	switch (c)
        {
        case 'o':
        	output_file = optarg;
        	break;
        case 'p':
        	sched_policy = optarg;
          	break;
        case 'r':
        	runlength = atof(optarg);
        	break;
        case 'h':
        	print_usage();
        	return 0;

        case '?':
            fprintf (stderr, "Unknown option character `\\x%x'.\n", optopt);
        default:
        	print_usage();
        	return 1;
        }
    
    // check for non optional arguments, input file name is the only options
    if ( (optind < argc) ) {
    	input_file = argv[optind++];
    	
    	// but signal an error if there are too many optional arguments
    	if ( (optind < argc) ) {
    		fprintf (stderr, "Too many non-option arguments %s\n", argv[optind]);
        	print_usage();
        	return 1;
    	}
    }
    
////////////////////////////////////////////////////////////////////////////////
// reading input
////////////////////////////////////////////////////////////////////////////////
	
	list<task> task_list; // periodic task list
	list<job> job_list; // aperiodic/sporadic job list (not implemented)
	ifstream infile;
	ios_base::iostate _ret = infile.exceptions ();
	infile.exceptions (ifstream::failbit | ifstream::badbit);
	try { // handle opening error
		infile.open (input_file, ifstream::in);
	}
	catch (ifstream::failure e) {
	    cout << "opening file " << input_file << " for input fails" << endl;
	    return 1;
	}
	infile.exceptions (_ret); 
	
	while (infile.good()) {
		task tmp_task;
		tmp_task.fromStream(infile);
		task_list.push_back(tmp_task); // the class will be copied
	}
	infile.close();	
	cout << "There are " << task_list.size() << " tasks:" << endl;

///////////////////////////////////////////////////////////////////////////////
// decimals
///////////////////////////////////////////////////////////////////////////////
		
	list<task>::iterator itask_list;
	task tmp_task;
	int tmp_decimals;
	int decimals = 0;

	for (itask_list = task_list.begin(); itask_list != task_list.end(); itask_list++) {
		tmp_task = *itask_list;
		tmp_decimals = tmp_task.getDecimals();
		if (tmp_decimals > decimals)
			decimals = tmp_decimals;
			
		tmp_task.toStream(cout);
	}
	cout << "Decimals: " << decimals << endl;			

////////////////////////////////////////////////////////////////////////////////
// runlength is passed as an argument or defined as 2 hyperperiods
////////////////////////////////////////////////////////////////////////////////

	// first task lcm = task period
	float mFactor = pow (10.0, decimals);
	itask_list = task_list.begin();
	tmp_task = *itask_list;
	float last = tmp_task.getPeriod();
	itask_list++;
		
	for (; itask_list != task_list.end(); itask_list++) {
		tmp_task = *itask_list;		
		last = static_cast<float>( lcm( static_cast<int>(last * mFactor), static_cast<int>(tmp_task.getPeriod() * mFactor) ) ) / mFactor;
	}
 	cout << "Hyperperiod: " << last << endl;
		
////////////////////////////////////////////////////////////////////////////////
// run the scheduling algorithm 
////////////////////////////////////////////////////////////////////////////////
	
 	if (runlength == 0.0)
 		runlength = last * 2; 

 	job_deque* policy = policy_deque[0];
 	for (unsigned int i=0; i<(sizeof(policy_deque)/sizeof(job_deque*)); i++)
 		if ( strcmp((const char*)policy_name[i], (const char*)sched_policy) == 0) {
 			policy = policy_deque[i];
 			cout << "Scheduling Policy is " << policy_name[i] << endl;
 			break;
 		}
 	
	scheduler sched(releaseDeq, *policy);	
	sched.run(task_list, job_list, runlength);
	deque<job*>& job_queue = sched.getTerminatedQueue(); 	
		
////////////////////////////////////////////////////////////////////////////////
// generate Kiwi output (this program will output only in Kiwi format) 
////////////////////////////////////////////////////////////////////////////////

	deque<event> events = jobToEventsList( job_queue );
		
	static const char kiwi_header[] = 
		"PALETTE Rainbow\n"
		"ZOOM_X 4\n"
		"ZOOM_Y	16\n"
		"COLOR EXEC-E 0 orchid4"; //\n";
		
	ofstream outfile;
	_ret = outfile.exceptions ();
	outfile.exceptions (ifstream::failbit | ifstream::badbit);
	try { // handle opening error
		outfile.open (output_file, ofstream::out);
	}
	catch (ofstream::failure e) {
	    cout << "opening file " << output_file << " for output fails" << endl;
	    return 1;
	}
	outfile.exceptions (_ret); 
		
	outfile << kiwi_header << endl;
	outfile << "DECIMAL_DIGITS " << decimals << endl;
	outfile << "DURATION " << runlength << endl;
	
	for (itask_list = task_list.begin(); itask_list != task_list.end(); itask_list++)
		outfile << "LINE_NAME " << (*itask_list).getId() << " " << (*itask_list).getName() << endl; 
	
	outfile.precision(decimals);
	outfile.setf(ios::fixed,ios::floatfield);
	// print out events
	outfile << endl;
	while (!events.empty()) {
		event tmp_event = events.back();
		tmp_event.toStream(outfile);
		events.pop_back();
	}
	outfile << endl;
	outfile.close();
	
	return EXIT_SUCCESS;
}
