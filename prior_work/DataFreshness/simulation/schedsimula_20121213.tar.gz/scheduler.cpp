#include <iostream>

#include <deque>
#include <list>

#include <string>
#include <algorithm>
#include <exception>
//#include <iterator>

using namespace std;

#include "operation.h"
#include "job.h"
#include "task.h"

#include "compare.h"
#include "job_deque.h"


#include "scheduler.h"


/*
 * i parametri quando si vanno a creare uno scheduler sono:
 * 1. la policy di scheduling
 * 2. la policy di event ordering
 */
//scheduler::scheduler(compare& eventCmp, compare& readyCmp)
//	: event_cmp(eventCmp), ready_cmp(readyCmp) {
scheduler::scheduler(job_deque& eventDeq, job_deque& readyDeq)
	: event_queue(eventDeq), ready_queue(readyDeq) {
//	: event_cmp(&eventCmp), ready_cmp(&readyCmp) { // anche con i puntatori non funziona cavolo!
	
	running = 0;
	current_time = 0.0;
}

scheduler::~scheduler() {
}

/*
 * initialize
 * This method creates the event_queue.
 * It takes as input a task list and a job (aperiodic/sporadic) list.
 * The last argument is the timespan in which we have to generate events. 
 */
int scheduler::init_event(list<task>& task_list, list<job>& job_list, float runlength) {
	
	// print out some debugging messages
	cout << "scheduler::init_event task_list.size: " << task_list.size() << " job_list.size: "
			<< job_list.size() << endl;

	// generating jobs, we access the task_list using iterators
	std::list<task>::iterator ilist;
	for (ilist = task_list.begin(); ilist != task_list.end(); ilist++) {
		task * tmp_task = &( *ilist);
		float time = tmp_task->getPhase();

		
		
		while (time < runlength) {
			// add a new job to the current task
			job * tmp_job = &( tmp_task->addJob( time, (time + tmp_task->getDeadline()), tmp_task->getExec() ) );
			// debugging messages
			cout << "job"<< tmp_job->getRelease() << ','
					<< tmp_job->getDeadline() << "," << tmp_job->getExec()
					<< 't' << (tmp_job->getParent()).getId() << ' ';

			// add a ptr to the event_queue
			event_queue.insert(tmp_job);	//.push_front(tmp_job);
			// increment to the next time period			
			time += tmp_task->getPeriod();
		}
		// debug message 
		cout << endl;
	}

	// copy the (aperiodic/sporadic) jobs, iterators to take ptrs
	// TODO

	// for debugging purposes print on stdout all jobs in sorted order
	//cout << "DEBUG ";
	//event_queue.toStream(cout);

	cout << "scheduler::init_event there are " << event_queue.size() << "events" << endl;

	return event_queue.size();
}

/*
 * init_ready
 * initializes the ready queue with all jobs of the same (initial) release time
 * does not require parameters but init_event must be called before,
 * otherwise return error. This routine sets the running job and the current time.  
 */
int scheduler::init_ready() {
	// on error return -1 (0 could be the number of jobs in the ready queue)
	if (event_queue.empty())
		return -1;

	// 1. move all same release time jobs to the ready queue
	do {
		//ready_queue.push_front(event_queue.front() );
		//event_queue.pop_front();
		ready_queue.insert( event_queue.remove( NULL) );
	} while ( !event_queue.empty()
			&& ((event_queue.extract(NULL))->getRelease() == (ready_queue.extract( NULL))->getRelease()));

	cout << "scheduler::init_ready elements on stack " << ready_queue.size() << endl;
	
	// 2. sort the ready queue using the selected scheduling policy
	//running = extractReady();
	running = ready_queue.remove( NULL);
	
	current_time = running->getRelease(); // prendo il release time => actual (current) time

	//TODO DEBUG
	cout << "scheduler::init_ready first task has id " << (running->getParent()).getId() << endl;
	cout << "scheduler::init_ready elements on stack " << ready_queue.size() << endl;
	
	return ready_queue.size();
}

/*
 * step_event
 * This method is the main scheduler loop.
 * It loops for events and proceed with the simulation of the schedule.
 */
int scheduler::step_event() {
	float finish_time;
	float event_time;
	
	//main loop of scheduling	
	while (!(event_queue.empty())) {
		// main objective: find next event (with timestamp) -- we choose to do not move every time to a next time event 
		// del tipo che non � il caso di generare operazioni contigue e poi andare a farne il merge � direttamente meglio non generarne troppe

		// calcolate finishing time of the current job
		finish_time = current_time + running->getExec();
		// DEBUG
		//cout << "finish time is " << finish_time << " task id " << (running->getParent()).getId() << endl;

		//job * tmp_job = event_queue.front() ;
		job * tmp_job = event_queue.extract( NULL) ;
		event_time = tmp_job->getRelease();

		// QUESTA VERSIONE del codice non considera di far uscire tutti i job con la stessa release time ma ne prende
		// UNO ALLA VOLTA

		if (finish_time >= event_time) { // current task can be preempted by a new task that will be released
			//move tmp_job in the ready_queue
			ready_queue.insert(tmp_job);
			event_queue.remove( NULL );

			if (event_time !=finish_time) {
				//move running in the ready_queue
				ready_queue.insert(running);
			}

			// extract the most prioritary job from the ready queue
			tmp_job = ready_queue.remove( NULL );

			//change running only if there is preemption otherwise continue loop
			// PREEMPTION
			if ( !((*tmp_job) == (*running))) {
/* this previous implementation adds also 0 time span events, but the check does not solve the problem ?!?!
				// generate operation on current job :: nota che usiamo event_time e non getRelease() che funzionerebbe solo se fosse l'ultimo a prendere il posto!!
				running->addOperation(current_time, event_time); // funziona sempre (a livello algoritmico) ma sopra facciamo copie perci� non va pi�..
				running->decExec(event_time - current_time); // funziona sempre (a livello algoritmico) ma sopra facciamo copie perci� non va pi�..
				// NOTA � probabile che qui stiamo aggiunggendo l'operazione anche ad un oggetto morto.. !?!?! ATTENZIONE!!!
*/				if ( float span = (event_time - current_time) ) {
					running->addOperation(current_time, event_time); 
					running->decExec( span );
				}

				//condizione di uguale
				if (event_time == finish_time)
					term_queue.push_back( running );

				current_time = event_time;

				//		delete running;
				running = tmp_job; //costruttore di copia!!! ????

				//delete tmp_job;
			}
		}
		else { // current task finishes execution
			// generate operation on current task
			if ( float span = (finish_time - current_time) ) {
				running->addOperation(current_time, finish_time); 
				//running->decExec( span );
			}
			
			term_queue.push_back( running );
			//		delete running;
			// actually running task give the cpu to other tasks
			current_time = finish_time;

			//vedo se ci sono elementi sullo stack che non vedono l'ora di essere eseguiti! :-)
			if (!ready_queue.empty()) {
				// extract the most prioritary job from the ready queue
				running = ready_queue.remove(NULL); //extractReady();					
			}
			else {
				// altrimenti devo per forza prendere l'elemento dalla coda degli eventi
				event_queue.remove( NULL);
				running = tmp_job;
				current_time = event_time;
			}
		}
	}
	
	return 0;
}

/*
 * step_ready
 * this method processes all reamining jobs on the ready_queue
 * a finalization step (that moves running in the term list) remains.
 */
int scheduler::step_ready () {
	float finish_time;

	cout << "scheduler::step_ready ready queue size " << ready_queue.size() << endl;

	// main loop: events are jobs termination
	while ( running ) {
		// calculate the finishing time
		finish_time = current_time + running->getExec();
		// DEBUG
		//cout << "finish time is " << finish_time << " task id " << (running->getParent()).getId() << endl;

		running->addOperation(current_time, finish_time);
		running->decExec(finish_time - current_time);
		term_queue.push_back( running);

		if ( !ready_queue.empty()  ) { // there are jobs on the event queue
			current_time = finish_time;

			// sort and get the most prioritary job on the queue
			running = ready_queue.remove(NULL); //extractReady();
		}
		else	// there are no jobs any more
			running = 0;
	}
	// return the number of objects in the ready queue, must be zero
	return ready_queue.size();
}

/*
 * run
 * simply call all methods iteratively
 */
void scheduler::run ( list<task>& task_list, list<job>& job_list, float runlength ) {
	init_event( task_list, job_list, runlength);
	
	init_ready();
	
	step_event();
	
	step_ready();

}
