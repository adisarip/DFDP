#include <iostream>
#include <string>
#include <list>

#include <fstream>

using namespace std;

extern "C" {
 #include <string.h>
}

#include "operation.h"
#include "job.h"
#include "task.h"


int task::count = 0;


int strdecimals (char* src) {
	char* result;
	result = strchr (src, '.');
	if ( !result )
		return -1;
	
	int zeroes = 0;
	int decimals = 0;
	while ( *(++result) != 0 ) {
		if ( *result == '0' ) {
			decimals++;
			zeroes++;
		}
		else if ( (*result >= '1') && (*result <= '9') ) {
			decimals++;
			zeroes = 0;
		}
		decimals -= zeroes;
	}
	
	return decimals;
}

void task::toStream(ostream& output) const
{
	output << name << ' ';
	output << phase << ' ' << period << ' ' << exec << ' ' << deadline << ' ';
	output << "id " << id << " util " << util << " decimals " << decimals; 
	output << endl;
}

#define MAX_LINE 256

#define PARSE_FLOAT(float_variable)		{ \
	start = input.tellg(); \
	if (! (input >> float_variable )) { \
		cerr << "task::fromStream error reading " << #float_variable << " arguments must be numerical" << endl; result--; } \
	end = input.tellg(); \
	if ( start != end) { \
		memset(subbuffer,0, 32); \
		strncpy(subbuffer, buffer + (start - offset), (end - start)); \
		tmp_decimals = strdecimals(subbuffer); \
		if (tmp_decimals > decimals) decimals = tmp_decimals; } \
	} \

int task::fromStream(istream& input)
{
	int tmp_decimals = 0;
	int result = 0;
	char buffer[MAX_LINE]; memset(buffer, 0, MAX_LINE); // teoricamente il C++ dovrebbe fare da solo tutto a zero
	char subbuffer[32]; 
	streampos start, end, offset, restore;
	
	offset = input.tellg();
	input.getline(buffer, MAX_LINE); // leggo una riga
	restore = input.tellg();
	input.seekg(offset); //restore previosu getline
	
	// if there are errors on the input stream it is necessary to clear them before continuing
	if (input.fail()){ cout << "task::fromStream input.fail true, cleared" << endl; input.clear(); }
	if (input.eof()){ cout << "task::fromStream input.eof true, cleared" << endl; input.clear(); }

	if (! (input >> name)) {
		cerr << "task::fromStream error reading name parameter" << endl; result--; }
	
	PARSE_FLOAT (phase);
	PARSE_FLOAT (period);
	PARSE_FLOAT (exec);
	PARSE_FLOAT (deadline);
	
	// metto il puntatore all'inizio delle nuova linea
	input.seekg(restore); // in questo modo � pi� semplice
	
	if ( period ) util = (float) exec / (float) period;
	else util = 0.0;
	
	return result;
}

bool task::operator< (const task& rhs) const // or lhs?
{
//	cout << "this " << deadline << " rhs " << rhs.deadline << endl;
	//return (deadline < rhs.getDeadline()); //if rhs - WORK
	return (deadline < rhs.deadline); //if rhs - WORK - because task is freind with itself :-)
	//return (rhs.deadline < deadline); //if lhs
}
/*
bool operator< (const task& lhs, const task& rhs) {
	return lhs.operator< (rhs);
}
*/

bool operator< (const task& lhs, const task * rhs) 
{	return (lhs < (*rhs)) ;	}

bool operator< (const task * lhs, const task& rhs) 
{	return ((*lhs) < rhs) ;	}


job& task::addJob(float r, float d, float e) {
	job tmp_job(*this, r, d, e);
	jobs.push_back(tmp_job);
	return jobs.back();
}
