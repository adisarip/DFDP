
#include <iostream>

#include <deque>
#include <list>

#include <string>
#include <algorithm>
#include <exception>

using namespace std;

#include "operation.h"
#include "job.h"
#include "task.h"

#include "compare.h"
#include "rm_compare.h"

#include "job_deque.h"
#include "rm_deque.h"


// Rate Monotonic RM


void rm_deque::insert (job* job_ptr) {
	_deque.push_back(job_ptr);	
}

job* rm_deque::extract (void* user) {
	stable_sort(_deque.begin(), _deque.end(), _compare);
	job* extracted = _deque.front();
	return extracted;
}

rm_deque::rm_deque()
{
}

rm_deque::~rm_deque()
{
}
