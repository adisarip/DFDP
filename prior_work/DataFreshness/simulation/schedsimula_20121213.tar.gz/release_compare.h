#ifndef RELEASE_COMPARE_H_
#define RELEASE_COMPARE_H_

struct release_compare : public compare
{
	bool operator() (const job& a,const job& b)
	{ //cout << "rel_comp job& job&" << endl;
		return (a.getRelease() < b.getRelease());
	}
	
	bool operator() (job*& a,job*& b)
	{ //cout << "rel_comp job*& job*&" << endl;
		return (a->getRelease() < b->getRelease());
	}

	bool operator() (job* const& a,job*& b)
	{ //cout << "rel_comp job* const& job*&" << endl;
		return (a->getRelease() < b->getRelease());
	}

	bool operator() (job*& a,job* const& b)
	{ //cout << "rel_comp job*& job* const&" << endl;
		return (a->getRelease() < b->getRelease());
	}
	
	~release_compare() { }
};

#endif /*RELEASE_COMPARE_H_*/
