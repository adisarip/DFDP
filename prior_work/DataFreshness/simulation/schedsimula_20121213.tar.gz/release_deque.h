#ifndef RELEASE_DEQUE_H_
#define RELEASE_DEQUE_H_

class release_deque : public job_deque
{
	release_compare _compare;
	
public:
	void insert (job* job_ptr);
	job* extract (void* user);
	
	release_deque();
	~release_deque();
};

#endif /*RELEASE_DEQUE_H_*/
