#ifndef JOB_H_
#define JOB_H_

// forward declaration of the class task
class task;

class job
{
protected:
	task * parent_task; // must be a reference (cannot be changed during operation)
	
	float release;
	float deadline;
	float exec;
	
	int id;
	int period_id;
		
	list<operation> operations;
	
public:
	job(const job& j) // copy constructor
	:parent_task(j.parent_task), release(j.release), deadline(j.deadline), exec(j.exec), period_id(j.period_id), operations(j.operations) 
	{};
	job(task& parent, float r, float d, float e)
	:parent_task (&parent), release(r), deadline(d), exec(e)
	{};
	job(task& parent)
	:parent_task (&parent)
	{};
	
	virtual ~job()
	{};
	
	job& operator= (const job& rhs); // assignment operator

	bool operator< (const job& rhs) const;
	bool operator== (const job& rhs) const;
		
	// standard get methods
	inline task& getParent() const
	{ return * parent_task; };
	inline float getRelease() const
	{ return release; };
	inline float getDeadline() const
	{ return deadline; };
	inline float getExec() const
	{ return exec; };
	
	
	// return the list of operations
	inline list<operation>& getList() 
	{ return operations; }; 
	
	
	float decExec(float e);
	
	operation& addOperation(float start, float stop);
	int checkOperation(); // go throught the list of operations checking if they are between release and deadline
};

#endif /*JOB_H_*/
