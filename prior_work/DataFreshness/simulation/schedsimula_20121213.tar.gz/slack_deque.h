#ifndef SLACK_DEQUE_H_
#define SLACK_DEQUE_H_

class slack_deque : public job_deque
{
	slack_compare _compare;
	
public:
	void insert (job* job_ptr);
	job* extract (void* user);
	
	slack_deque();
	~slack_deque();
};

#endif /*SLACK_DEQUE_H_*/
