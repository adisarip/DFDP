#include <list>
//#include <vector>
#include <string>
using namespace std;

#include "operation.h"
#include "job.h"
#include "task.h"


operation& job::addOperation(float start, float stop) {
	operation tmp_op(*this, start, stop);
	operations.push_back(tmp_op);
	return operations.back();
}

int job::checkOperation() {
	list<operation>::iterator op_it;
	for (op_it = operations.begin(); op_it != operations.end(); op_it++) {
		operation tmp_op = *op_it;
		if (tmp_op.getBegin() < release)
			return -1; // errore
		else if (tmp_op.getEnd() > deadline)
			return 1; // not schedulable
	}
	
	return 0;
}

float job::decExec(float e) {
	exec -= e;
	return exec;
}

bool job::operator< (const job& rhs) const // or lhs?
{
//	cout << "this " << deadline << " rhs " << rhs.deadline << endl;
	//return (deadline < rhs.getDeadline()); //if rhs - WORK
	return (release > rhs.release); //if rhs - WORK - because task is freind with itself :-)
	//return (rhs.deadline < deadline); //if lhs
}

/*
 * operator==
 * NOTA SAREBBE MEGLIO CONFRONTARE PER PUNTATORE
 */
bool job::operator== (const job& rhs) const {
	return ( (parent_task == rhs.parent_task) &&
			(release == rhs.release) &&
			(deadline == rhs.deadline) &&
			(exec == rhs.exec) &&
			(period_id == rhs.period_id) );
}


// quando viene usato l'operatore =
// non � possibile copiare reference membri
// viene chiamato sul lhs e ritorna *this su chi viene chiamato
// (molto strano come design choice..
// massivamente usato nella vector<job> dobbiamo farlo come puntatore il ref al parent
job& job::operator= (const job& rhs) {
	// costruttore di copia � richiesto da..
//	job * tmp = new job (rhs.parent_task);
	
	if ( this == &rhs )
		return (*this);
	
	this->parent_task = rhs.parent_task; // non abbiamo potuto usare un ref perche STL chiama di continuo l'operatore di copia.. BUON DESIGN CHOICE? probabilmente no
	this->release = rhs.release;
	this->deadline = rhs.deadline;
	this->exec = rhs.exec;
	this->period_id = rhs.period_id;
	this->operations = rhs.operations; // to be copied but... what to do with previous content?
	
	return (*this); //sempre ritornare *this perch� e right chained come operazione!!!
}
