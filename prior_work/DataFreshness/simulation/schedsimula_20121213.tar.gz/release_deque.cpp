
#include <iostream>

#include <deque>
#include <list>

#include <string>
#include <algorithm>
#include <exception>
#include <iterator>

using namespace std;

#include "operation.h"
#include "job.h"
#include "task.h"

#include "compare.h"
#include "release_compare.h"

#include "job_deque.h"
#include "release_deque.h"


// eventi ordinati dopo l'inserzione


void release_deque::insert (job* job_ptr) {
	_deque.push_back(job_ptr);
	stable_sort(_deque.begin(), _deque.end(), _compare);
}

job* release_deque::extract (void* user) {
	job* extracted = _deque.front();
	return extracted;
}

release_deque::release_deque()
{
}

release_deque::~release_deque()
{
}
